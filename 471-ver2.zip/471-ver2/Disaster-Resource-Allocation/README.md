# Disaster-Resource-Allocation-
Ai integrated smart resource allocation program intended to efficiently allocate Manpower and equipment in  large or small scale Disasters.   
